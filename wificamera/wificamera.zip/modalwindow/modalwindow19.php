<div class="container ModalWindow OPEN19">
        <div class="row justify-content-lg-center">
            <div class="images_modalwindow">
                <a class="fancyimage" data-fancybox-group="group" href="/content/wifi 4mix 1mp + wifi 4mix 2mp/1.jpg"><img src="/content/wifi 4mix 1mp + wifi 4mix 2mp/1.jpg" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/wifi 4mix 1mp + wifi 4mix 2mp/2.jpg"><img src="/content/wifi 4mix 1mp + wifi 4mix 2mp/2.jpg" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/wifi 4mix 1mp + wifi 4mix 2mp/3.jpg"><img src="/content/wifi 4mix 1mp + wifi 4mix 2mp/3.jpg" alt=""></a>
                <!-- <a class="fancyimage" data-fancybox-group="group" href="/content/wifi 4mix 1mp + wifi 4mix 2mp/CHD-30S_HD_3.1_583aca82-cd82-4f02-a140-0caa0b6d7a83_1024x1024.jpg"><img src="/content/wifi 4mix 1mp + wifi 4mix 2mp/CHD-30S_HD_3.1_583aca82-cd82-4f02-a140-0caa0b6d7a83_1024x1024.jpg" alt=""></a> -->
                </br>
                <a class="fancyimage" data-fancybox-group="group" href="/content/wifi 4mix 1mp + wifi 4mix 2mp/minideleteconect.jpg"><img src="/content/wifi 4mix 1mp + wifi 4mix 2mp/minideleteconect.jpg" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/wifi 4mix 1mp + wifi 4mix 2mp/how_to_constructed_complect.png"><img src="/content/wifi 4mix 1mp + wifi 4mix 2mp/how_to_constructed_complect.png" alt=""></a>
                <!-- <a class="fancyimage" data-fancybox-group="group" href="/content/wifi 4mix 1mp + wifi 4mix 2mp/Included-AHD2_Mix_grande.jpg"><img src="/content/wifi 4mix 1mp + wifi 4mix 2mp/Included-AHD2_Mix_grande.jpg" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/wifi 4mix 1mp + wifi 4mix 2mp/Mixed_set_AHD-17_br_4x2.0MP_CAM_1xDVR_grande.jpg"><img src="/content/wifi 4mix 1mp + wifi 4mix 2mp/Mixed_set_AHD-17_br_4x2.0MP_CAM_1xDVR_grande.jpg" alt=""></a> -->
            </div>
            <p></p>
            <div class="characteristics_modalwindow">
                <p>Распаковка комплекта видео:<a href="https://youtu.be/YGJW3wn_JIE">
                www.youtu.be/YGJW3wn_JIE</a> </p> 
                <h3>Комплект видеонаблюдения Partizan WiFi 2out2mp</h3>
                <p>Основное отличие данного комплекта – беспроводные камеры высокого качества и LCD дисплей, что позволяет сэкономить на покупке монитора.
                Partizan – надежное оборудование сборки Украина, успешно продаеться на рынке ЕС. Сертифицированное с гарантией 3 года. Достойно Вашего внимания!




                </p>
                <ul>
                    <h5>Описание</h5>
                    <li>Готовый комплект системы видеонаблюдения, включая цветные камеры HD разрешения, гибридного видеорегистратора, обжатого кабеля (не нужно ничего паять) и других составляющих обеспечивающих простую установку и настройку без участия профильных специалистов</li>
                    <li>Система из IP камер высокого разрешения для широкого спектра задач</li>
                    <li>Комплект видеонаблюдения отлично подойдет для установки в частном доме, на даче или квартире, а так же может быть использован в бизнесе как видеонаблюдение для магазина, склада, офиса, кафе, различных станций и сервисных центров</li>
                    <li>Прост и легок в установке и настройке, все кабеля предварительно обжаты, а интерфейс меню интуитивно понятный и легкий в управлении</li>
                    <li>Удаленный доступ через устройства на базе ПО iOS и Android;</li>
                    <li>Наличие ряда полезных дополнительный функции охранного характера: датчик движения, закрытие объектива, обрыв или перебой сигнала. Так же запись выставляется на выбор: постоянная, по движению или по графику с автоматической перезаписью</li>
                    <li>Поддержка функционала «интеллекта»: фиксация изменения положения указанных предметов, пересечение периметра, реакция на не стабильный сигнал</li>
                    <li>Wi-Fi. Встроенная антенна для беспроводного соединения</li>
                    <li>LCD Display для мониторинга видео с камер IP</li>
                    <li>Удаленный доступ через устройства на базе ПО iOS и Android</li>
                </ul>
                <ul>
                    <p>Характеристики</p>
                    <li>Качество изображения – цветное FullHD (1080p)</li>
                    <li>•   Тип камер  видеонаблюдения – IP камеры</li>
                    <li>Угол обзора купольной и уличной камеры – 75 градусов</li>
                    <li>Материал корпуса камеры – металл</li>
                    <li>Дальность ночной инфракрасной подсветки купольной камеры – 30 м</li>
                    <li>Тип купольной/уличной камеры видеонаблюдения – универсального применения для помещения или улицы (-40°С ~ +60°С)</li>
                    <li>Размер матрицы камеры – 1/2,8”</li>
                    <li>К-во каналов видеорегистратора – записывает до 4 WiFi камер</li>
                </ul>
                <ul>
                <p>Комплектация</p>
                    <li>Видеокамера AHD уличная Wi-Fi IP камера (2.0 MP) – 2 шт</li>
                    <li>Видеорегистратор Wi-Fi NVR (видеорегистратор) + LCD Display 10” – 1 шт</li>
                    <li>Блок питания 12V 1A – 2шт</li>
                    <li>Wi-Fi антенна – 3 шт</li>
                    <li>Интернет кабель обжатый  (патч корд) – 1 м</li>
                    <li>Мышь компьютерная – 1 шт</li>
                    <li>Инструкция/наклейки/диск – 1 шт</li>
                    <li>Жесткий диск преобритается отдельно</li>
                </ul>
                <p>Установка и запуск камеры по инструкции займут несколько минут.
                <br>
                Камера предварительно настроена и готова к работе.
                </p>
                   
                <p></p>
            </div>
           <center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
            <a class="close">X</a>
        </div>
    </div>