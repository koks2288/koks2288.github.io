<div class="container ModalWindow OPEN11">
        <div class="row justify-content-lg-center">
            <div class="images_modalwindow">
                <a class="fancyimage" data-fancybox-group="group" href="/content/Dahua_DH-IPC-C15P/Dahua DH-IPC-C15P.jpg"><img src="/content/Dahua_DH-IPC-C15P/Dahua DH-IPC-C15P.jpg" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/Dahua_DH-IPC-C15P/Dahua DH-IPC-C15P-2.png"><img src="/content/Dahua_DH-IPC-C15P/Dahua DH-IPC-C15P-2.png" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/Dahua_DH-IPC-C15P/Dahua DH-IPC-C15P-4.jpg"><img src="/content/Dahua_DH-IPC-C15P/Dahua DH-IPC-C15P-4.jpg" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/Dahua_DH-IPC-C15P/s-1-1000x1000.jpg"><img src="/content/Dahua_DH-IPC-C15P/s-1-1000x1000.jpg" alt=""></a>
                </br>
                <a class="fancyimage" data-fancybox-group="group" href="/content/Dahua_DH-IPC-C15P/DH-IPC-C15P-pic004-600x600.jpg"><img src="/content/Dahua_DH-IPC-C15P/DH-IPC-C15P-pic004-600x600.jpg" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/Dahua_DH-IPC-C15P/Dahua DH-IPC-C15P-3.jpg"><img src="/content/Dahua_DH-IPC-C15P/Dahua DH-IPC-C15P-3.jpg" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/Dahua_DH-IPC-C15P/Dahua DH-IPC-C15P-6.jpg"><img src="/content/Dahua_DH-IPC-C15P/Dahua DH-IPC-C15P-6.jpg" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/Dahua_DH-IPC-C15P/Dahua DH-IPC-C15P-7.jpg"><img src="/content/Dahua_DH-IPC-C15P/Dahua DH-IPC-C15P-7.jpg" alt=""> </a>
            </div>
            <p></p>
            <div class="characteristics_modalwindow">
                <p>Распаковка комплекта видео:<a href="https://youtu.be/Xzoq34kM7g8">
                www.youtu.be/Xzoq34kM7g8</a> </p>
                <h3>WiFi камера Dahua DH-IPC-C15P</h3>
                <p>Основное отличие данной WiFi камеры видеонаблюдения – стильный дизайн в совмещении и широкоугольная камера. Присутствуют все самые необходимые опции: качество HD, совместима с PC и мобильными устройствами на базе iOS, Android, WiFi, поддержка карты памяти, двустороняя аудиосвязь!
                Dahua, это лидер на рынке видеонаблюдения в мире! 
                Качественный облачный сервис для архива от компании Dahua - Easy for Ip.


                </p>
                <ul>
                    <h5>Описание</h5>
                    <li>Цветная поворотная WiFi камера IP с качеством HD разрешения, с упрощенной установкой и настройкой и вам не понадобится участие профильных специалистов</li>
                    <li>Данная IP камера, отлично подойдет для установки в частном доме, на даче или квартире, а так же может быть использована в бизнесе как видеонаблюдение для магазина, офиса, кафе, и других не больших помещений</li>
                    <li>Камера уже настроена и готова к использованию, проста и легкая в установке и настройке, интерфейс меню интуитивно понятный и легкий в управлении</li>
                    <li>Наличие ряда полезных дополнительный функции: автоматическая ночная подсветка, двусторонняя аудиосвязь, обнаружение движения, защита паролем. Так же запись выставляется на выбор: постоянная, по движению или по графику с автоматической перезаписью</li>
                    <li>Поддержка функционала «интеллекта»: фиксация изменения положения указанных предметов, пересечение периметра, реакция на не стабильный сигнал;</li>
                    <li>Удаленный доступ через устройства на базе ПО iOS и Android;</li>
                    <li>Магнитная площадка на ножке. Предназначена для устанавливки на плоскую поверхность. Регулируемые шарниры позволят выставить правльное направление камеры.</li>
                    <li>Особая полезная охранная функция тревожное оповещение, позволяет не только записать видео в случае обнаружения движения в зоне видимости но и оповестить громким звуковым сигналом через динамик устройства, а так же сигнал в приложении на телефоне.</li>
                </ul>
                <ul>
                    <p>Характеристики</p>
                    <li>Качество изображения – цветное HD (1,3Мп)</li>
                    <li>Угол обзора - 125 градусов</li>
                    <li>Тип камер  видеонаблюдения – IP WiFi камеры</li>
                    <li>Материал корпуса  – высококачественный пластик белого цвета</li>
                    <li>Дальность ночной инфракрасной подсветки – 10м</li>
                    <li>Тип камеры видеонаблюдения – для помещений(-10°С ~ +60°С)</li>
                    <li>Размер матрицы камеры – 1/3” Progressive Scan CMOS</li>
                    <li>Слот для SD карты до 128 Мб под хранение архива</li>
                    <li>Тревожное оповещение на  на динамике устройства и на телефоне (через приложение)</li>
                </ul>
                
                <p>Установка и запуск камеры по инструкции займут несколько минут.
                <br>
                Камера предварительно настроена и готова к работе.
                </p>
                   
                <p></p>
            </div>
           <center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
            <a class="close">X</a>
        </div>
    </div>