<div class="container ModalWindow OPEN9">
        <div class="row justify-content-lg-center">
            <div class="images_modalwindow">
                <a class="fancyimage" data-fancybox-group="group" href="/content/Dahua_4mix_2mp/02005_1-1000x1000.jpg"><img src="/content/Dahua_4mix_2mp/02005_1-1000x1000.jpg" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/Dahua_4mix_2mp/02005_6-1000x1000.jpg"><img src="/content/Dahua_4mix_2mp/02005_6-1000x1000.jpg" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/Dahua_4mix_2mp/02006_8-1000x1000.jpg"><img src="/content/Dahua_4mix_2mp/02006_8-1000x1000.jpg" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/Dahua_4mix_2mp/hdw1200rp-s3-3-1000x1000.jpg"><img src="/content/Dahua_4mix_2mp/hdw1200rp-s3-3-1000x1000.jpg" alt=""></a>
                </br>
                <a class="fancyimage" data-fancybox-group="group" href="/content/Dahua_4mix_2mp/02007-1000x1000.jpg"><img src="/content/Dahua_4mix_2mp/02007-1000x1000.jpg" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/Dahua_4mix_2mp/02005_3-1000x1000.jpg"><img src="/content/Dahua_4mix_2mp/02005_3-1000x1000.jpg" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/Dahua_4mix_2mp/minideleteconect.jpg"><img src="/content/Dahua_4mix_2mp/minideleteconect.jpg" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/Dahua_4mix_2mp/how_to_constructed_complect.png"><img src="/content/Dahua_4mix_2mp/how_to_constructed_complect.png" alt=""> </a>
            </div>
            <p></p>
            <div class="characteristics_modalwindow">
                <p>Распаковка комплекта видео:<a href="https://www.youtube.com/watch?v=rUxrGqZjyNM&t">www.youtube.com/watch?v=rUxrGqZjyNM&t</a> </p>
                <h3>Комплект видеонаблюдения Dahua 4MIX2mp</h3>
                <p>Основное отличие данного комплекта –  надежное видеонаблюдение проверенное временем по низкой цене.
                    Так же Tecsar, это качественное и сертифицированное виденаблюдение производства Украина, потому логично имеет очень высокую популярность на рынке.
                </p>
                <ul>
                    <h5>Описание</h5>
                    <li>Готовый комплект системы видеонаблюдения, включая цветные камеры высокого разрешения, гибридного видеорегистратора, обжатого кабеля (не нужно ничего паять) и других составляющих обеспечивающих простую установку без участия профильных специалистов;</li>
                    <li>Комплект видеонаблюдения отлично подойдет для установки в частном доме, на даче или квартире, а так же может быть использован в бизнесе как видеонаблюдение для магазина, склада, офиса, кафе, различных станций и сервисных центров;</li>
                    <li>Прост и легок в установке и настройке, все кабеля предварительно обжаты, а интерфейс меню интуитивно понятный и легкий в управлении;</li>
                    <li>Наличие ряда полезных дополнительный функции охранного характера: датчик движения, закрытие объектива, обрыв или перебой сигнала. Так же запись выставляется на выбор: постоянная, по движению или по графику с автоматической перезаписью;</li>
                    <li>Поддержка функционала «интеллекта»: фиксация изменения положения указанных предметов, пересечение периметра, реакция на не стабильный сигнал;</li>
                    <li>Удаленный доступ через устройства на базе ПО iOS и Android;</li>
                </ul>
                <ul>
                    <p>Характеристики</p>
                    <li>Качество изображения – цветное FullHD (1080p)</li>
                    <li>Угол обзора камеры – 65 градусов</li>
                    <li>Материал корпуса уличной/купольной камеры – пластик</li>
                    <li>Дальность ночной инфракрасной подсветки уличной/купольной камеры  – 20м</li>
                    <li>Тип камер видеонаблюдения – универсального применения для помещения или улицы (-20°С ~ +60°С)</li>
                    <li>Тип уличной камеры видеонаблюдения – универсального применения для помещения или улицы (-40°С ~ +60°С)</li>
                    <li>К-во каналов видеорегистратора – записывает до 4 камер через  BNC входы</li>
                    <li>Выходы VGA/HDMI регистратора – есть</li>
                    <li>Размер матрицы камеры - 1/2,7</li>
                </ul>
                <ul>
                <p>Комплектация</p>
                    <li>Видеокамера HD-CVI уличная DH-HFW1200R-S3– 2 шт.</li>
                    <li>ВидеокамераHD-CVI купольная DH-HDW1200R-S3– 2 шт.</li>
                    <li>Видеорегистратор HD-CVI DH-HCVR5104HS-S3– 1 шт</li>
                    <li>Блок питания 12V 1A – 1шт.</li>
                    <li>Кабель обжатый 18,5м.  – 4шт.</li>
                    <li>Разветвитель питания – 1 шт.</li>
                    <li>Мышь компьютерная – 1 шт.</li>
                    <li>Интернет кабель обжатый  (патч корд) – 5м.</li>
                    <li>Инструкция/наклейки/диск – 1 шт.</li>
                    <li>Жесткий диск преобритается отдельно.</li>
                </ul>
                <p></p>
            </div>
           <center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
            <a class="close">X</a>
        </div>
    </div>