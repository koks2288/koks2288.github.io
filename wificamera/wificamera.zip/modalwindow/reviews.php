<div class="ModalWindow reviews_modal " id="ModalWindow">
        <a class="close" id="close">X</a>

        <form method="post" action="" id="formMain" name="formMain" >
            <h2>Отправьте нам свой отзыв</h2> 
            
            <input id="telephone" type="number" name="telephone"  placeholder="Ваш телефон...." maxlength="30" autocomplete="off" required/>
            <input id="mail" type="email" name="mail"  placeholder="Ваш Email...." maxlength="30" autocomplete="off" required/>
            <input id="button" name="send" type="submit" value="Отправить отзыв"/>
            <br>
            <br>
            <textarea cols="35" id="name" name="name" type="text" placeholder="Отзыв"></textarea> 
        </form>
    </div>