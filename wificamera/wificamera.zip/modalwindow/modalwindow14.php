<div class="container ModalWindow OPEN14">
        <div class="row justify-content-lg-center">
            <div class="images_modalwindow">
                <a class="fancyimage" data-fancybox-group="group" href="/content/Dahua_IP_wifi_2out_3mp/_-91012_12v_2a_1__5.jpg"><img src="/content/Dahua_IP_wifi_2out_3mp/_-91012_12v_2a_1__5.jpg" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/Dahua_IP_wifi_2out_3mp/976c67997f8a3ee1473d50cc16487c41.jpg"><img src="/content/Dahua_IP_wifi_2out_3mp/976c67997f8a3ee1473d50cc16487c41.jpg" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/Dahua_IP_wifi_2out_3mp/kit-ip43-2b-w-1000x1000.png"><img src="/content/Dahua_IP_wifi_2out_3mp/kit-ip43-2b-w-1000x1000.png" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/Dahua_IP_wifi_2out_3mp/NVR4108HS-W-S2.jpg"><img src="/content/Dahua_IP_wifi_2out_3mp/NVR4108HS-W-S2.jpg" alt=""></a>
                </br>
                <a class="fancyimage" data-fancybox-group="group" href="/content/Dahua_IP_wifi_2out_3mp/minideleteconect.jpg"><img src="/content/Dahua_IP_wifi_2out_3mp/minideleteconect.jpg" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/Dahua_IP_wifi_2out_3mp/how_to_constructed_complect.jpg"><img src="/content/Dahua_IP_wifi_2out_3mp/how_to_constructed_complect.png" alt=""></a>
                <!--<a class="fancyimage" data-fancybox-group="group" href="/content/Dahua_IP_wifi_2out_3mp/reg-1000x1000.jpg"><img src="/content/Dahua_IP_wifi_2out_3mp/reg-1000x1000.jpg" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/Dahua_IP_wifi_2out_3mp/Dahua DH-IPC-C15P-7.jpg"><img src="/content/Dahua_IP_wifi_2out_3mp/Dahua DH-IPC-C15P-7.jpg" alt=""> </a> -->
            </div>
            <p></p>
            <div class="characteristics_modalwindow">
                <p>Распаковка комплекта видео:<a href="https://www.youtube.com/watch?v=DxUh-jt3_fQ&feature=youtu.be">
                www.youtube.com/watch?v=DxUh-jt3_fQ&feature=youtu.be</a> </p>
                <h3>Комплект видеонаблюдения Dahua IP WiFi 2out3mp</h3>
                <p>Основное отличие данного комплекта видеоанблюдения – беспроводные WiFi камеры видеонаблюдения высокого 3Мр!!! разрешения с удобной и простой настройкой.
                Dahua, это лидер на рынке видеонаблюдения в мире! 


                </p>
                <ul>
                    <h5>Описание</h5>
                    <li>Готовый комплект системы видеонаблюдения, включая цветные камеры WiFi FullHD (3 mp) разрешения, гибридного WiFi видеорегистратора, обжатого кабеля (не нужно ничего паять) и других составляющих обеспечивающих простую установку и настройку без участия профильных специалистов</li>
                    <li>Система из IP камер высокого разрешения для широкого спектра задач</li>
                    <li>Комплект видеонаблюдения отлично подойдет для установки в частном доме, на даче или квартире, а так же может быть использован в бизнесе как видеонаблюдение для магазина, склада, офиса, кафе, различных станций и сервисных центров</li>
                    <li>Прост и легок в установке и настройке, все кабеля предварительно обжаты, а интерфейс меню интуитивно понятный и легкий в управлении</li>
                    <li>Удаленный доступ через устройства на базе ПО iOS и Android;</li>
                    <li>Наличие ряда полезных дополнительный функции охранного характера: датчик движения, закрытие объектива, обрыв или перебой сигнала. Так же запись выставляется на выбор: постоянная, по движению или по графику с автоматической перезаписью</li>
                    <li>Поддержка функционала «интеллекта»: фиксация изменения положения указанных предметов, пересечение периметра, реакция на не стабильный сигнал</li>
                </ul>
                <ul>
                    <p>Характеристики</p>
                    <li>Качество изображения – цветное FullHD (3 mp)</li>
                    <li>Угол обзора - 77 градусов</li>
                    <li>Тип камер  видеонаблюдения – IP WiFi камеры</li>
                    <li>Материал корпуса  уличной/купольной камеры –металл + пластик</li>
                    <li>Дальность ночной инфракрасной подсветки уличной/купольной камеры – 30 м</li>
                    <li>Тип купольной/уличной камеры видеонаблюдения – универсального применения для помещения или улицы (-40°С ~ +60°С)</li>
                    <li>Размер матрицы камеры – 1/3” Progressive CMOS</li>
                    <li>Выходы VGA/HDMI регистратора – есть</li>
                    <li>К-во каналов видеорегистратора – 4 канала записи и отображения по WiFi/li>
                    <li>Максимум доступа 20 пользователей</li>
                </ul>
                <ul>
                <p>Комплектация</p>
                    <li>Видеокамера HD-CVI уличная DH-IPC-HFW1320S-W – 2 шт.</li>
                    <li>Видеорегистратор DH-NVR4104HS-W-S2 – 1 шт.</li>
                    <li>Интернет кабель обжатый  (патч корд) – 5 м.</li>
                    <li>Мышь компьютерная – 1 шт.</li>
                    <li>Инструкция/наклейки/диск – 1 шт.</li>
                    <li>Жесткий диск преобритается отдельно.</li>
                </ul>
                <p>Установка и запуск камеры по инструкции займут несколько минут.
                <br>
                Камера предварительно настроена и готова к работе.
                </p>
                   
                <p></p>
            </div>
            <center><button class="main_button_all_catalog vizov_buy " >Заказать</button></center>
            <a class="close">X</a>
        </div>
    </div>