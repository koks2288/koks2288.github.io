<div class="container ModalWindow OPEN16">
        <div class="row justify-content-lg-center">
            <div class="images_modalwindow">
                <a class="fancyimage" data-fancybox-group="group" href="/content/4mix 1mp + 4mix 2mp/12_V5A_1024x1024_798eb75d-c651-4cf7-9721-ae560bef3bca_grande.jpg"><img src="/content/4mix 1mp + 4mix 2mp/12_V5A_1024x1024_798eb75d-c651-4cf7-9721-ae560bef3bca_grande.jpg" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/4mix 1mp + 4mix 2mp/cable_AHD-coax_power-black_95abb0af-08b9-48fb-9a80-04035a3f6d74_grande.jpg"><img src="/content/4mix 1mp + 4mix 2mp/cable_AHD-coax_power-black_95abb0af-08b9-48fb-9a80-04035a3f6d74_grande.jpg" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/4mix 1mp + 4mix 2mp/CDM-223S-IR_HD_3.2_19b12cee-3752-4bf1-b28f-8c9514617d3a_grande.jpg"><img src="/content/4mix 1mp + 4mix 2mp/CDM-223S-IR_HD_3.2_19b12cee-3752-4bf1-b28f-8c9514617d3a_grande.jpg" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/4mix 1mp + 4mix 2mp/CHD-30S_HD_3.1_583aca82-cd82-4f02-a140-0caa0b6d7a83_1024x1024.jpg"><img src="/content/4mix 1mp + 4mix 2mp/CHD-30S_HD_3.1_583aca82-cd82-4f02-a140-0caa0b6d7a83_1024x1024.jpg" alt=""></a>
                </br>
                <a class="fancyimage" data-fancybox-group="group" href="/content/4mix 1mp + 4mix 2mp/minideleteconect.jpg"><img src="/content/4mix 1mp + 4mix 2mp/minideleteconect.jpg" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/4mix 1mp + 4mix 2mp/how_to_constructed_complect.png"><img src="/content/4mix 1mp + 4mix 2mp/how_to_constructed_complect.png" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/4mix 1mp + 4mix 2mp/Included-AHD2_Mix_grande.jpg"><img src="/content/4mix 1mp + 4mix 2mp/Included-AHD2_Mix_grande.jpg" alt=""></a>
                <a class="fancyimage" data-fancybox-group="group" href="/content/4mix 1mp + 4mix 2mp/Mixed_set_AHD-17_br_4x2.0MP_CAM_1xDVR_grande.jpg"><img src="/content/4mix 1mp + 4mix 2mp/Mixed_set_AHD-17_br_4x2.0MP_CAM_1xDVR_grande.jpg" alt=""> </a>
            </div>
            <p></p>
            <div class="characteristics_modalwindow">
                <p>Распаковка комплекта видео:<a href="https://youtu.be/mk-hHE1SKug">
                www.youtu.be/mk-hHE1SKug</a> </p>
                <h3>Комплект видеонаблюдения Partizan 4MIX1mp</h3>
                <p>Основное отличие данного комплекта – удобный чемодан в который упакован комплект гарантия сохранности и качества.
                Partizan – надежное оборудование сборки Украина, успешно продаеться на рынке ЕС. Сертифицированное с гарантией 3 года. Достойно Вашего внимания!



                </p>
                <ul>
                    <h5>Описание</h5>
                    <li>Готовый комплект системы видеонаблюдения, включая цветные камеры HD разрешения, гибридного видеорегистратора, обжатого кабеля (не нужно ничего паять) и других составляющих обеспечивающих простую установку и настройку без участия профильных специалистов</li>
                    <li>Комплект видеонаблюдения отлично подойдет для установки в частном доме, на даче или квартире, а так же может быть использован в бизнесе как видеонаблюдение для магазина, склада, офиса, кафе, различных станций и сервисных центров</li>
                    <li>Прост и легок в установке и настройке, все кабеля предварительно обжаты, а интерфейс меню интуитивно понятный и легкий в управлении</li>
                    <li>Удаленный доступ через устройства на базе ПО iOS и Android;</li>
                    <li>Наличие ряда полезных дополнительный функции охранного характера: датчик движения, закрытие объектива, обрыв или перебой сигнала. Так же запись выставляется на выбор: постоянная, по движению или по графику с автоматической перезаписью</li>
                    <li>Поддержка функционала «интеллекта»: фиксация изменения положения указанных предметов, пересечение периметра, реакция на не стабильный сигнал</li>
                </ul>
                <ul>
                    <p>Характеристики</p>
                    <li>Качество изображения – цветное HD (720p)</li>
                    <li>Угол обзора - 70 градусов</li>
                    <li>Угол обзора купольной камеры – 90 градусов</li>
                    <li>Материал корпуса  уличной камеры – металл</li>
                    <li>Материал корпуса  уличной камеры – пластик</li>
                    <li>Дальность ночной инфракрасной подсветки уличной камеры – 25 м</li>
                    <li>Дальность ночной инфракрасной подсветки купольной камеры – 20 м</li>
                    <li>Тип купольной/уличной камеры видеонаблюдения – универсального применения для помещения или улицы (+10°С ~ +60°С)</li>
                    <li>Тип уличной камеры видеонаблюдения – универсального применения для помещения или улицы (-20°С ~ +60°С)</li>
                    <li>Размер матрицы камеры – 1/4”</li>
                    <li>Выходы VGA/HDMI регистратора – есть</li>
                    <li>К-во каналов видеорегистратора – через  BNC входы</li>
                </ul>
                <ul>
                <p>Комплектация</p>
                    <li>Видеокамера AHD купольная CDM-223S-IR HD– 2 шт</li>
                    <li>Видеокамера AHD уличная COD-331S HD – 2 шт</li>
                    <li>Видеорегистратор AHD CHD-30S HD – 1 шт</li>
                    <li>Блок питания 12V 5A – 1шт</li>
                    <li>Кабель обжатый 18,5м.  – 4 шт</li>
                    <li>Разветвитель питания – 1 шт</li>
                    <li>Интернет кабель обжатый  (патч корд) – 5 м</li>
                    <li>Мышь компьютерная – 1 шт</li>
                    <li>Инструкция/наклейки/диск – 1 шт</li>
                    <li>Жесткий диск преобритается отдельно</li>
                </ul>
                <p>Установка и запуск камеры по инструкции займут несколько минут.
                <br>
                Камера предварительно настроена и готова к работе.
                </p>
                   
                <p></p>
            </div>
           <center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
            <a class="close">X</a>
        </div>
    </div>