<div class="ModalWindow buy " id="ModalWindow">
        <a class="close" id="close">X</a>

        <form method="post" action="" id="formMain" name="formMain" >
            <h2>Выберите товар и сделайте заказ</h2> 
                <select id="name" type="text" size="0" name="name" required>
                    <option selected disabled>Выберите товар</option>
                    <option name="name" value="Модель: Tecsar 1OUT">Модель: Tecsar 1OUT</option>
                    <option name="name" value="Модель: Tecsar 2OUT">Модель: Tecsar 2OUT</option>
                    <option name="name" value="Модель: Tecsar 2OUT LUX LITE">Модель: Tecsar 2OUT LUX LITE</option>
                    <option name="name" value="Модель: Tecsar 2OUT Var">Модель: Tecsar 2OUT Var</option>
                    <option name="name" value="Модель: Tecsar 4OUT">Модель: Tecsar 4OUT</option>
                    <option name="name" value="Модель: Tecsar 4OUT LUX">Модель: Tecsar 4OUT LUX</option>
                    <option name="name" value="Модель: Tecsar 6dom LUX LITE">Модель: Tecsar 6dom LUX LITE</option>
                    <option name="name" value="Модель: Tecsar 8OUT-MIX">Модель: Tecsar 8OUT-MIX</option>
                    <option name="name" value="Модель: Dahua 4MIX HD">Модель: Dahua 4MIX HD</option>
                    <option name="name" value="Модель: Dahua 4MIX HD">Модель: Dahua 4MIX HD</option>
                    <option name="name" value="Модель: Dahua DH-IPC-A15P">Модель: Dahua DH-IPC-A15P</option>
                    <option name="name" value="Модель: Dahua DH-IPC-C15P">Модель: Dahua DH-IPC-C15P</option>
                    <option name="name" value="Модель: Dahua DH-IPC-K15P">Модель: Dahua DH-IPC-K15P</option>
                    <option name="name" value="Модель: Dahua IP 4MIX FullHD">Модель: Dahua IP 4MIX FullHD</option>
                    <option name="name" value="Модель: Dahua IP WiFi 2OUT 3mp">Модель: Dahua IP WiFi 2OUT 3mp</option>
                    <option name="name" value="Модель: SEVEN IP-720">Модель: SEVEN IP-720</option>
                    <option name="name" value="Модель: Partizan 4MIX HD">Модель: Partizan 4MIX HD</option>
                    <option name="name" value="Модель: Partizan 4MIX FullHD">Модель: Partizan 4MIX FullHD</option>
                    <option name="name" value="Модель: Partizan WiFi 2Out HD">Модель: Partizan WiFi 2Out HD</option>
                    <option name="name" value="Модель: Partizan WiFi 2Out FullHD">Модель: Partizan WiFi 2Out FullHD</option>
                </select>
            <input id="telephone" type="number" name="telephone"  placeholder="Ваш телефон...." maxlength="30" autocomplete="off" required/>
            <input id="mail" type="email" name="mail"  placeholder="Ваш Email...." maxlength="30" autocomplete="off" required/>
            <input id="kod" type="text" name="kod"  placeholder="Предложите свою цену" maxlength="30" autocomplete="off"/>
            <input id="button" name="send" type="submit" value="Заказать звонок"/>
        </form>
    </div>