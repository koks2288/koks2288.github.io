$(window).scroll(function(){
	/*var st = $(this).scrollTop();
	
	$(".parallax img").css({
		"transform": "translate(0%, -"+ st  +"%"
	});*/
});


//PlaginScroll
$(document).ready(function(){
	$('.go_to1').on("click", "a", function(event){
		//отменяем стандартную обработку нажатия по ссылке
		event.preventDefault();
		var go = $(this).attr('href'), // возьмем содержимое атрибута href, должен быть селектором, т.е. например начинаться с # или .
		top = $(go).offset().top;
		$('body,html').animate({scrollTop: top - 200}, 1500);
	    return false; // выключаем стандартное действие

	});
});
//FixedMenu
$(document).ready(function(){
 
        var $menu = $("#main_menu");
 
        $(window).scroll(function(){
            if ( $(this).scrollTop() > 100 && $menu.hasClass("main_menu") ){
                $menu.removeClass("main_menu").addClass("fixed");
            } else if($(this).scrollTop() <= 100 && $menu.hasClass("fixed")) {
                $menu.removeClass("fixed").addClass("main_menu");
            }
        });//scroll
    });
//ModalWindow
$(document).ready(function(){
	$( ".vizov_buy" ).click(function() {
 		$(".ModalWindow").removeClass("active");
 		$(".buy").addClass("active");
 		console.log('lol'); 
	});
	$( ".vizov" ).click(function() {
 		$(".OPEN").addClass("active");
 		console.log('0'); 
	});
	$( ".vizov1" ).click(function() {
 		$(".OPEN1").addClass("active");
 		console.log('1'); 
	});
	$( ".vizov2" ).click(function() {
 		$(".OPEN2").addClass("active");
 		console.log('2'); 
	});
	$( ".vizov3" ).click(function() {
 		$(".OPEN3").addClass("active");
 		console.log('3'); 
	});
	$( ".vizov4" ).click(function() {
 		$(".OPEN4").addClass("active");
 		console.log('4'); 
	});
	$( ".vizov5" ).click(function() {
 		$(".OPEN5").addClass("active");
 		console.log('5'); 
	});
	$( ".vizov6" ).click(function() {
 		$(".OPEN6").addClass("active");
 		console.log('6'); 
	});
	$( ".vizov7" ).click(function() {
 		$(".OPEN7").addClass("active");
 		console.log('7'); 
	});
	$( ".vizov8" ).click(function() {
 		$(".OPEN8").addClass("active");
 		console.log('8'); 
	});
	$( ".vizov9" ).click(function() {
 		$(".OPEN9").addClass("active");
 		console.log('9'); 
	});
	$( ".vizov10" ).click(function() {
 		$(".OPEN10").addClass("active");
 		console.log('10'); 
	});
	$( ".vizov11" ).click(function() {
 		$(".OPEN11").addClass("active");
 		console.log('11'); 
	});
	$( ".vizov12" ).click(function() {
 		$(".OPEN12").addClass("active");
 		console.log('12'); 
	});
	$( ".vizov13" ).click(function() {
 		$(".OPEN13").addClass("active");
 		console.log('13'); 
	});
	$( ".vizov14" ).click(function() {
 		$(".OPEN14").addClass("active");
 		console.log('14'); 
	});
	$( ".vizov15" ).click(function() {
 		$(".OPEN15").addClass("active");
 		console.log('15'); 
	});
	$( ".vizov16" ).click(function() {
 		$(".OPEN16").addClass("active");
 		console.log('16'); 
	});
	$( ".vizov17" ).click(function() {
 		$(".OPEN17").addClass("active");
 		console.log('17'); 
	});
	$( ".vizov18" ).click(function() {
 		$(".OPEN18").addClass("active");
 		console.log('18'); 
	});
	$( ".vizov19" ).click(function() {
 		$(".OPEN19").addClass("active");
 		console.log('19'); 
	});
	$( ".vizov_reviews" ).click(function() {
 		$(".reviews_modal").addClass("active");
 		console.log('reviews_modal'); 
	});
});


//Close
$(document).ready(function(){
	$( ".close" ).click(function() {
 		$(".ModalWindow").removeClass("active");
 		console.log('redy'); 
	});
});