<?php
	require 'link/header.php';
?>

	

<?php
	require 'link/footer.php';
?>	

