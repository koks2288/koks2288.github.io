<?php
	require '../link/header.php';
?>
	<a style="margin-left:90px; color:red; font-size: 18px; font-weight: bold; text-transform:uppercase;" href="/index.php">Вернуться на главную</a>
	<div class="container-fluid accessories_tehnology">
		<h2>Компьютерная техника</h2>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/1.jpg" alt="">
					<p>Жесткий диск Western Digital Purple 1TB 64MB WD10PURZ</p>
					<p>Цена - 1590грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/1.jpg" alt="">
					<p>Жесткий диск Western Digital Purple 2TB 64MB WD20PURZ</p>
					<p>Цена - 2288грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/1.jpg" alt="">
					<p>Жесткий диск Western Digital Purple 3TB 64MB WD30PURZ</p>
					<p>Цена - 3174грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/1.jpg" alt="">
					<p>Жесткий диск Western Digital Purple 4TB 64MB WD40PURZ</p>
					<p>Цена - 3850грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/1.jpg" alt="">
					<p>Жесткий диск Western Digital Purple 6TB 64MB WD60PURZ</p>
					<p>Цена - 6469грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/1.jpg" alt="">
					<p>Жесткий диск Western Digital Purple 8TB 128MB WD80PURZ</p>
					<p>Цена - 324грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/1.jpg" alt="">
					<p>Жесткий диск Western Digital Purple 10TB 256MB WD100PURZ</p>
					<p>Цена - 450грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/1.jpg" alt="">
					<p>Винчестер 1 TB Western Digital Purple WD10PURX</p>
					<p>Цена - 59грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/1.jpg" alt="">
					<p>Винчестер 2 TB Western Digital Purple WD20PURX</p>
					<p>Цена - 85грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/1.jpg" alt="">
					<p>Винчестер 3 TB Western Digital Purple WD30PURX</p>
					<p>Цена - 114грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/1.jpg" alt="">
					<p>Винчестер 4 TB Western Digital Purple WD40PURX</p>
					<p>Цена - 153грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/1.jpg" alt="">
					<p>Винчестер 6 TB Western Digital Purple WD60PURX</p>
					<p>Цена - 260грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/2.jpg" alt="">
					<p>Жесткий диск Seagate BarraCuda HDD 500GB 7200rpm 32MB ST500DM009 3.5 SATA II</p>
					<p>Цена - 50грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/2.jpg" alt="">
					<p>Жесткий диск Seagate BarraCuda HDD 1TB 7200rpm 64MB ST1000DM010 3.5 SATA III</p>
					<p>Цена - 53,98грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/2.jpg" alt="">
					<p>Жесткий диск Seagate BarraCuda HDD 2TB 7200rpm 64MB ST2000DM006 3.5 SATA III</p>
					<p>Цена - 79,55грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/2.jpg" alt="">
					<p>Жесткий диск Seagate BarraCuda HDD 3TB 7200rpm 64MB ST3000DM008 3.5 SATA III</p>
					<p>Цена - 105,69грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/2.jpg" alt="">
					<p>Жесткий диск Seagate BarraCuda HDD 4TB 7200rpm 64MB ST4000DM005 3.5 SATA III</p>
					<p>Цена - 123грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/2.jpg" alt="">
					<p>Жесткий диск Seagate BarraCuda Pro HDD 6TB 7200rpm 256MB ST6000DM004 3.5 SATA III</p>
					<p>Цена - 276грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/2.jpg" alt="">
					<p>Жесткий диск Seagate BarraCuda Pro HDD 8TB 7200rpm 256MB ST8000DM005 3.5 SATA III</p>
					<p>Цена - 377,28грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/2.jpg" alt="">
					<p>Жесткий диск Seagate BarraCuda Pro HDD 10TB 7200rpm 256MB ST10000DM0004 3.5 SATA III</p>
					<p>Цена - 455грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/3.jpg" alt="">
					<p>Жесткий диск Seagate IronWolf HDD 1TB 5900rpm 64MB ST1000VN002 3.5 SATAIII</p>
					<p>Цена - 67грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/3.jpg" alt="">
					<p>Жесткий диск Seagate IronWolf HDD 2TB 5900rpm 64MB ST2000VN004 3.5 SATAIII</p>
					<p>Цена - 88грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/3.jpg" alt="">
					<p>Жесткий диск Seagate IronWolf HDD 3TB 5900rpm 64MB ST3000VN007 3.5 SATAIII</p>
					<p>Цена - 122,73грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/3.jpg" alt="">
					<p>Жесткий диск Seagate IronWolf HDD 4TB 5900rpm 64MB ST4000VN008 3.5 SATAIII</p>
					<p>Цена - 152,28грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/3.jpg" alt="">
					<p>Жесткий диск Seagate IronWolf HDD 6TB 7200rpm 128MB ST6000VN0041 3.5 SATAIII</p>
					<p>Цена - 232,96грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/3.jpg" alt="">
					<p>Жесткий диск Seagate IronWolf Pro HDD 6TB 7200rpm 256MB ST6000NE0021 3.5 SATAIII</p>
					<p>Цена - 323,87грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/3.jpg" alt="">
					<p>Жесткий диск Seagate IronWolf HDD 10TB 7200rpm 256MB ST10000VN0004 3.5 SATAIII</p>
					<p>Цена - 459,10грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/3.jpg" alt="">
					<p>Жесткий диск Seagate IronWolf Pro HDD 10TB 7200rpm 256MB ST10000NE0004 3.5 SATAIII</p>
					<p>Цена - 505,69грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/4.jpg" alt="">
					<p>Жесткий диск Seagate SkyHawk HDD 1TB 5900rpm 64MB ST1000VX005 3.5 SATAIII</p>
					<p>Цена - 55,50грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/4.jpg" alt="">
					<p>Жесткий диск Seagate SkyHawk HDD 2TB 5900rpm 64MB ST2000VX008 3.5 SATAIII</p>
					<p>Цена - 79грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/4.jpg" alt="">
					<p>Жесткий диск Seagate SkyHawk HDD 3TB 5900rpm 64MB ST3000VX010 3.5 SATAIII</p>
					<p>Цена - 106грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/4.jpg" alt="">
					<p>Жесткий диск Seagate SkyHawk HDD 4TB 5900rpm 64MB ST4000VX007 3.5 SATAIII</p>
					<p>Цена - 136грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/4.jpg" alt="">
					<p>Жесткий диск Seagate SkyHawk HDD 6TB 7200rpm 256MB ST6000VX0023 3.5 SATAIII</p>
					<p>Цена - 211грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/4.jpg" alt="">
					<p>Жесткий диск Seagate SkyHawk HDD 8TB 7200rpm 256MB ST8000VX0022 3.5 SATAIII</p>
					<p>Цена - 278грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/4.jpg" alt="">
					<p>Жесткий диск Seagate SkyHawk HDD 10TB 7200rpm 256MB ST10000VX0004 3.5 SATAIII</p>
					<p>Цена - 388грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/5.jpg" alt="">
					<p>Карта памяти Kingston 16GB microSDHC C10 UHS-I (SDC10G2/16GBSP)</p>
					<p>Цена - 245грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/6.jpg" alt="">
					<p>Карта памяти Kingston MicroSDHC 16GB Class 10 UHS-I + SD адаптер (SDC10G2/16GB)</p>
					<p>Цена - 249грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/7.jpg" alt="">
					<p>Карта памяти Kingston MicroSD 16GB Class 10 UHS-I (SDCA10/16GBSP)</p>
					<p>Цена - 285грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/8.jpg" alt="">
					<p>Карта памяти Kingston 16GB microSDHC C10 + SD адаптер (SDCA10/16GB)</p>
					<p>Цена - 289грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/5.jpg" alt="">
					<p>Карта памяти Kingston MicroSDHC/MicroSDXC 32GB Class 10 UHS-I (SDC10G2/32GBSP)</p>
					<p>Цена - 445грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/8.jpg" alt="">
					<p>Карта памяти Kingston MicroSDHC/MicroSDXC 32GB Class 10 UHS-I + SD адаптер (SDC10G2/32GB)</p>
					<p>Цена - 449грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/9.jpg" alt="">
					<p>Карта памяти Kingston 32GB microSDHC C10 UHS-I U3 Action (SDCAC/32GBSP)</p>
					<p>Цена - 545грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/10.jpg" alt="">
					<p>Карта памяти Kingston 32GB microSDHC C10 UHS-I U3+ SD адаптер Action (SDCAC/32GB)</p>
					<p>Цена - 549грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/7.jpg" alt="">
					<p>Карта памяти Kingston 32GB microSDHC C10 (SDCA10/32GBSP)</p>
					<p>Цена - 565грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/5.jpg" alt="">
					<p>Карта памяти Kingston 64GB microSDXC C10 UHS-I (SDC10G2/64GBSP)</p>
					<p>Цена - 795грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/6.jpg" alt="">
					<p>Карта памяти Kingston 64GB microSDXC C10 UHS-I+ SD адаптер (SDC10G2/64GB)</p>
					<p>Цена - 799грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/6.jpg" alt="">
					<p>Карта памяти Kingston 128GB microSDXC C10 UHS-I+ SD адаптер (SDC10G2/128GB)</p>
					<p>Цена - 1639грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/11.jpg" alt="">
					<p>Карта памяти Transcend 16GB microSDHC C10 UHS-I (TS16GUSDCU1)</p>
					<p>Цена - 239,69грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/12.jpg" alt="">
					<p>Карта памяти Transcend 32Gb microSDHC class 10 (TS32GUSDC10)</p>
					<p>Цена - 439грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/13.jpg" alt="">
					<p>Карта памяти Transcend 32Gb microSDHC class 10 + SD адаптер (TS32GUSDHC10)</p>
					<p>Цена - 449грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/14.jpg" alt="">
					<p>Карта памяти Transcend 64GB microSDXC C10 + SD адаптер (TS64GUSDU1)</p>
					<p>Цена - 929грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<!-- <div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_tehnology/12.jpg" alt="">
					<p>Жесткий диск Seagate IronWolf Pro HDD 10TB 7200rpm 256MB ST10000NE0004 3.5 SATAIII</p>
					<p>Цена - 505,69грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div> -->
		</div>
	</div>


	<!-- ModalWindow buy -->
	<div class="ModalWindow buy " id="ModalWindow">
        <a class="close" id="close">X</a>

        <form method="post" action="/form.php" id="formMain" name="formMain" >
            <h2>Выберите товар и сделайте заказ</h2> 
                <select id="name" type="text" size="0" name="hero[]" required>
                    <option selected disabled>Выберите товар</option>
                    <option value="Жесткий диск Western Digital Purple 1TB 64MB WD10PURZ">Жесткий диск Western Digital Purple 1TB 64MB WD10PURZ</option>
                    <option value="Жесткий диск Western Digital Purple 2TB 64MB WD20PURZ">Жесткий диск Western Digital Purple 2TB 64MB WD20PURZ</option>
                    <option value="Жесткий диск Western Digital Purple 3TB 64MB WD30PURZ">Жесткий диск Western Digital Purple 3TB 64MB WD30PURZ</option>
                    <option value="Жесткий диск Western Digital Purple 4TB 64MB WD40PURZ">Жесткий диск Western Digital Purple 4TB 64MB WD40PURZ</option>
                    <option value="Жесткий диск Western Digital Purple 6TB 64MB WD60PURZ">Жесткий диск Western Digital Purple 6TB 64MB WD60PURZ</option>
                    <option value="Жесткий диск Western Digital Purple 8TB 128MB WD80PURZ">Жесткий диск Western Digital Purple 8TB 128MB WD80PURZ</option>
                    <option value="Жесткий диск Western Digital Purple 10TB 256MB WD100PURZ">Жесткий диск Western Digital Purple 10TB 256MB WD100PURZ</option>
                    <option value="Винчестер 1 TB Western Digital Purple WD10PURX">Винчестер 1 TB Western Digital Purple WD10PURX</option>
                    <option value="Винчестер 2 TB Western Digital Purple WD20PURX">Винчестер 2 TB Western Digital Purple WD20PURX</option>
                    <option value="Винчестер 3 TB Western Digital Purple WD30PURX">Винчестер 3 TB Western Digital Purple WD30PURX</option>
                    <option value="Винчестер 4 TB Western Digital Purple WD40PURX">Винчестер 4 TB Western Digital Purple WD40PURX</option>
                    <option value="Винчестер 6 TB Western Digital Purple WD60PURX">Винчестер 6 TB Western Digital Purple WD60PURX</option>
                    <option value="Жесткий диск Seagate BarraCuda HDD 500GB 7200rpm 32MB ST500DM009 3.5 SATA II">Жесткий диск Seagate BarraCuda HDD 500GB 7200rpm 32MB ST500DM009 3.5 SATA II</option>
                    <option value="Жесткий диск Seagate BarraCuda HDD 1TB 7200rpm 64MB ST1000DM010 3.5 SATA III">Жесткий диск Seagate BarraCuda HDD 1TB 7200rpm 64MB ST1000DM010 3.5 SATA III</option>
                    <option value="Жесткий диск Seagate BarraCuda HDD 2TB 7200rpm 64MB ST2000DM006 3.5 SATA III">Жесткий диск Seagate BarraCuda HDD 2TB 7200rpm 64MB ST2000DM006 3.5 SATA III</option>
                    <option value="Жесткий диск Seagate BarraCuda HDD 3TB 7200rpm 64MB ST3000DM008 3.5 SATA III">Жесткий диск Seagate BarraCuda HDD 3TB 7200rpm 64MB ST3000DM008 3.5 SATA III</option>
                    <option value="Жесткий диск Seagate BarraCuda HDD 4TB 7200rpm 64MB ST4000DM005 3.5 SATA III">Жесткий диск Seagate BarraCuda HDD 4TB 7200rpm 64MB ST4000DM005 3.5 SATA III</option>
                    <option value="Жесткий диск Seagate BarraCuda Pro HDD 6TB 7200rpm 256MB ST6000DM004 3.5 SATA III">Жесткий диск Seagate BarraCuda Pro HDD 6TB 7200rpm 256MB ST6000DM004 3.5 SATA III</option>
                    <option value="Жесткий диск Seagate BarraCuda Pro HDD 8TB 7200rpm 256MB ST8000DM005 3.5 SATA III">Жесткий диск Seagate BarraCuda Pro HDD 8TB 7200rpm 256MB ST8000DM005 3.5 SATA III</option>
                    <option value="Жесткий диск Seagate BarraCuda Pro HDD 10TB 7200rpm 256MB ST10000DM0004 3.5 SATA III">Жесткий диск Seagate BarraCuda Pro HDD 10TB 7200rpm 256MB ST10000DM0004 3.5 SATA III</option>
                    <option value="Жесткий диск Seagate IronWolf HDD 1TB 5900rpm 64MB ST1000VN002 3.5 SATAIII">Жесткий диск Seagate IronWolf HDD 1TB 5900rpm 64MB ST1000VN002 3.5 SATAIII</option>
                    <option value="Жесткий диск Seagate IronWolf HDD 2TB 5900rpm 64MB ST2000VN004 3.5 SATAIII">Жесткий диск Seagate IronWolf HDD 2TB 5900rpm 64MB ST2000VN004 3.5 SATAIII</option>
                    <option value="Жесткий диск Seagate IronWolf HDD 3TB 5900rpm 64MB ST3000VN007 3.5 SATAIII">Жесткий диск Seagate IronWolf HDD 3TB 5900rpm 64MB ST3000VN007 3.5 SATAIII</option>
                    <option value="Жесткий диск Seagate IronWolf HDD 4TB 5900rpm 64MB ST4000VN008 3.5 SATAIII">Жесткий диск Seagate IronWolf HDD 4TB 5900rpm 64MB ST4000VN008 3.5 SATAIII</option>
                    <option value="Жесткий диск Seagate IronWolf HDD 6TB 7200rpm 128MB ST6000VN0041 3.5 SATAIII">Жесткий диск Seagate IronWolf HDD 6TB 7200rpm 128MB ST6000VN0041 3.5 SATAIII</option>
                    <option value="Жесткий диск Seagate IronWolf Pro HDD 6TB 7200rpm 256MB ST6000NE0021 3.5 SATAIII">Жесткий диск Seagate IronWolf Pro HDD 6TB 7200rpm 256MB ST6000NE0021 3.5 SATAIII</option>
                    <option value="Жесткий диск Seagate IronWolf HDD 10TB 7200rpm 256MB ST10000VN0004 3.5 SATAIII">Жесткий диск Seagate IronWolf HDD 10TB 7200rpm 256MB ST10000VN0004 3.5 SATAIII</option>
                    <option value="Жесткий диск Seagate IronWolf Pro HDD 10TB 7200rpm 256MB ST10000NE0004 3.5 SATAIII">Жесткий диск Seagate IronWolf Pro HDD 10TB 7200rpm 256MB ST10000NE0004 3.5 SATAIII</option>
                    <option value="Жесткий диск Seagate SkyHawk HDD 1TB 5900rpm 64MB ST1000VX005 3.5 SATAIII">Жесткий диск Seagate SkyHawk HDD 1TB 5900rpm 64MB ST1000VX005 3.5 SATAIII</option>
                    <option value="Жесткий диск Seagate SkyHawk HDD 2TB 5900rpm 64MB ST2000VX008 3.5 SATAIII">Жесткий диск Seagate SkyHawk HDD 2TB 5900rpm 64MB ST2000VX008 3.5 SATAIII</option>
                    <option value="Жесткий диск Seagate SkyHawk HDD 3TB 5900rpm 64MB ST3000VX010 3.5 SATAIII">Жесткий диск Seagate SkyHawk HDD 3TB 5900rpm 64MB ST3000VX010 3.5 SATAIII</option>
                    <option value="Жесткий диск Seagate SkyHawk HDD 4TB 5900rpm 64MB ST4000VX007 3.5 SATAIII">Жесткий диск Seagate SkyHawk HDD 4TB 5900rpm 64MB ST4000VX007 3.5 SATAIII</option>
                    <option value="Жесткий диск Seagate SkyHawk HDD 6TB 7200rpm 256MB ST6000VX0023 3.5 SATAIII">Жесткий диск Seagate SkyHawk HDD 6TB 7200rpm 256MB ST6000VX0023 3.5 SATAIII</option>
                    <option value="Жесткий диск Seagate SkyHawk HDD 8TB 7200rpm 256MB ST8000VX0022 3.5 SATAIII">Жесткий диск Seagate SkyHawk HDD 8TB 7200rpm 256MB ST8000VX0022 3.5 SATAIII</option>
                    <option value="Жесткий диск Seagate SkyHawk HDD 10TB 7200rpm 256MB ST10000VX0004 3.5 SATAIII">Жесткий диск Seagate SkyHawk HDD 10TB 7200rpm 256MB ST10000VX0004 3.5 SATAIII</option>
                    <option value="Карта памяти Kingston 16GB microSDHC C10 UHS-I (SDC10G2/16GBSP)">Карта памяти Kingston 16GB microSDHC C10 UHS-I (SDC10G2/16GBSP)</option>
                    <option value="Карта памяти Kingston MicroSDHC 16GB Class 10 UHS-I + SD адаптер (SDC10G2/16GB)">Карта памяти Kingston MicroSDHC 16GB Class 10 UHS-I + SD адаптер (SDC10G2/16GB)</option>
                    <option value="Карта памяти Kingston MicroSD 16GB Class 10 UHS-I (SDCA10/16GBSP)">Карта памяти Kingston MicroSD 16GB Class 10 UHS-I (SDCA10/16GBSP)</option>
                    <option value="Карта памяти Kingston 16GB microSDHC C10 + SD адаптер (SDCA10/16GB)">Карта памяти Kingston 16GB microSDHC C10 + SD адаптер (SDCA10/16GB)</option>
                    <option value="Карта памяти Kingston MicroSDHC/MicroSDXC 32GB Class 10 UHS-I (SDC10G2/32GBSP)">Карта памяти Kingston MicroSDHC/MicroSDXC 32GB Class 10 UHS-I (SDC10G2/32GBSP)</option>
                    <option value="Карта памяти Kingston MicroSDHC/MicroSDXC 32GB Class 10 UHS-I + SD адаптер (SDC10G2/32GB)">Карта памяти Kingston MicroSDHC/MicroSDXC 32GB Class 10 UHS-I + SD адаптер (SDC10G2/32GB)</option>
                    <option value="Карта памяти Kingston 32GB microSDHC C10 UHS-I U3 Action (SDCAC/32GBSP)">Карта памяти Kingston 32GB microSDHC C10 UHS-I U3 Action (SDCAC/32GBSP)</option>
                    <option value="Карта памяти Kingston 32GB microSDHC C10 UHS-I U3+ SD адаптер Action (SDCAC/32GB)">Карта памяти Kingston 32GB microSDHC C10 UHS-I U3+ SD адаптер Action (SDCAC/32GB)</option>
                    <option value="Карта памяти Kingston 32GB microSDHC C10 (SDCA10/32GBSP)">Карта памяти Kingston 32GB microSDHC C10 (SDCA10/32GBSP)</option>
                    <option value="Карта памяти Kingston 64GB microSDXC C10 UHS-I (SDC10G2/64GBSP)">Карта памяти Kingston 64GB microSDXC C10 UHS-I (SDC10G2/64GBSP)</option>
                    <option value="Карта памяти Kingston 64GB microSDXC C10 UHS-I+ SD адаптер (SDC10G2/64GB)">Карта памяти Kingston 64GB microSDXC C10 UHS-I+ SD адаптер (SDC10G2/64GB)</option>
                    <option value="Карта памяти Kingston 128GB microSDXC C10 UHS-I+ SD адаптер (SDC10G2/128GB)">Карта памяти Kingston 128GB microSDXC C10 UHS-I+ SD адаптер (SDC10G2/128GB)</option>
                    <option value="Карта памяти Transcend 16GB microSDHC C10 UHS-I (TS16GUSDCU1)">Карта памяти Transcend 16GB microSDHC C10 UHS-I (TS16GUSDCU1)</option>
                    <option value="Карта памяти Transcend 32Gb microSDHC class 10 (TS32GUSDC10)">Карта памяти Transcend 32Gb microSDHC class 10 (TS32GUSDC10)</option>
                    <option value="Карта памяти Transcend 32Gb microSDHC class 10 + SD адаптер (TS32GUSDHC10)">Карта памяти Transcend 32Gb microSDHC class 10 + SD адаптер (TS32GUSDHC10)</option>
                    <option value="Карта памяти Transcend 64GB microSDXC C10 + SD адаптер (TS64GUSDU1)">Карта памяти Transcend 64GB microSDXC C10 + SD адаптер (TS64GUSDU1)</option>
                    </select>
            <input id="telephone" type="number" name="telephone"  placeholder="Ваш телефон...." maxlength="30" autocomplete="off" required/>
            <input id="mail" type="email" name="mail"  placeholder="Ваш Email...." maxlength="30" autocomplete="off" required/>
            <input id="button" name="send" type="submit" value="Заказать товар"/>
        </form>
    </div>

<?php
	require '../link/footer.php';

?>	
