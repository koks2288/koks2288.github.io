<?php
	require '../link/header.php';
?>
	<title>Источники питания</title>
	<a style="margin-left:90px; color:red; font-size: 18px; font-weight: bold; text-transform:uppercase;" href="/index.php">Вернуться на главную</a>
	<div class="container-fluid accessories_pitanie">
		<h2>Источники питания</h2>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/1.jpg" alt="">
					<p>Блок питания Full Energy BGW-122 12В/2А</p>
					<p>Цена - 249,9грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/2.jpg" alt="">
					<p>PSW-240-12G</p>
					<p>Цена - 1025,7грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/3.jpg" alt="">
					<p>PSW-250-12</p>
					<p>Цена - 1025,7грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/4.jpg" alt="">
					<p>HKA-A24250-230</p>
					<p>Цена - 454,4грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/5.jpg" alt="">
					<p>"Блок питания Foscam 5В 2А DC"</p>
					<p>Цена - 263грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/6.jpg" alt="">
					<p>Блок питания Foscam 12В 2А DC</p>
					<p>Цена - 289,3грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/7.jpg" alt="">
					<p>Страж 1,5А</p>
					<p>Цена - 164,4грн</p
	
						<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/8.jpg" alt="">
					<p>Страж М-910/12</p>
					<p>Цена - 189,4грн</p
	
						<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/9.jpg" alt="">
					<p>Страж М-910</p>
					<p>Цена - 103,9грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/10.jpg" alt="">
					<p>Блок питания ATABA-1230 12V/3A с кабелем питания</p>
					<p>Цена - 315,6грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/11.jpg" alt="">
					<p>Страж М-924</p>
					<p>Цена - 315,6грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/12.jpg" alt="">
					<p>Страж М-912</p>
					<p>Цена - 420,8грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>	
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/13.jpg" alt="">
					<p>Блок бесперебойного питания Full Energy BBG-124/4</p>
					<p>Цена - 697грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/14.jpg" alt="">
					<p>Блок бесперебойного питания Full Energy BBG-1210/8</p>
					<p>Цена - 1525,4грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/15.jpg" alt="">
					<p>Блок бесперебойного питания Kraft PSU-1203LED</p>
					<p>Цена - 552,3грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/16.jpg" alt="">
					<p>Блок бесперебойного питания Kraft PSU-1203/4CH</p>
					<p>Цена - 867,9грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/17.jpg" alt="">
					<p>Блок бесперебойного питания Kraft PSU-1205LED</p>
					<p>Цена - 710грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/18.jpg" alt="">
					<p>Блок бесперебойного питания Kraft PSU-1205/8CH</p>
					<p>Цена - 999,4грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/19.jpg" alt="">
					<p>Блок бесперебойного питания Kraft PSU-1210LED</p>
					<p>Цена - 1578грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/20.jpg" alt="">
					<p>Блок бесперебойного питания Kraft PSU-1210/16CH</p>
					<p>Цена - 1709,5грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/21.jpg" alt="">
					<p>Источник бесперебойного питания SVS-DC12A8-8/17</p>
					<p>Цена - 1130,9грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/22.jpg" alt="">
					<p>Блок бесперебойного питания Trinix PSU 6A 12B</p>
					<p>Цена - 1393грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/23.jpg" alt="">
					<p>Блок бесперебойного питания Nikton ББП50Л-12Б</p>
					<p>Цена - 789грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/24.jpg" alt="">
					<p>Блок бесперебойного питания Nikton ББП125И-12Б</p>
					<p>Цена - 1972,5грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/25.jpg" alt="">
					<p>Блок бесперебойного питания Nikton ББП40М-12Б</p>
					<p>Цена - 1841грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/26.jpg" alt="">
					<p>Аккумуляторная батарея Full Energy 12V 1.2Ah (FEP-121)</p>
					<p>Цена - 210,4грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/27.jpg" alt="">
					<p>Аккумуляторная батарея Full Energy 12V 2,2Ah (FEP-122)</p>
					<p>Цена - 263грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/28.jpg" alt="">
					<p>Аккумуляторная батарея Full Energy 12V 4Ah (FEP-124)</p>
					<p>Цена - 215,6грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/29.jpg" alt="">
					<p>Аккумуляторная батарея Full Energy 12V 7Ah (FE-7-12)</p>
					<p>Цена - 368,2грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/30.jpg" alt="">
					<p>Аккумуляторная батарея Full Energy 12V 12Ah (FE-1212)</p>
					<p>Цена - 789грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/31.jpg" alt="">
					<p>Аккумуляторная батарея Full Energy 12V 18Ah (FEP-1218)</p>
					<p>Цена - 1078,3грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/32.jpg" alt="">
					<p>Аккумуляторная батарея Trinix АКБ 12V 1,2Ah</p>
					<p>Цена - 210,4грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/33.jpg" alt="">
					<p>Аккумуляторная батарея Trinix АКБ 12V 4Ah</p>
					<p>Цена - 302,5грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/34.jpg" alt="">
					<p>Аккумуляторная батаре Trinix АКБ 12V 7Ah</p>
					<p>Цена - 394,5грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/35.jpg" alt="">
					<p>Аккумуляторная батарея Trinix АКБ 12V 18Ah</p>
					<p>Цена - 1183,5грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/36.jpg" alt="">
					<p>BAT-6V4.5AH</p>
					<p>Цена - 135,7грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/37.jpg" alt="">
					<p>BAT-12V7AH</p>
					<p>Цена - 368,3грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/38.jpg" alt="">
					<p>BAT-12V9AH</p>
					<p>Цена - 434грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/39.jpg" alt="">
					<p>BAT-12V12AH</p>
					<p>Цена - 591,8грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/40.jpg" alt="">
					<p>BAT-12V17AH/4</p>
					<p>Цена - 789грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/41.jpg" alt="">
					<p>BAT-12V30AH</p>
					<p>Цена - 1735,8грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/42.jpg" alt="">
					<p>BAT-12V40AH</p>
					<p>Цена - 2130,3грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/43.jpg" alt="">
					<p>BAT-12V55AH</p>
					<p>Цена - 2787,8грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/44.jpg" alt="">
					<p>BAT-12V80AH</p>
					<p>Цена - 3760,9грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/45.jpg" alt="">
					<p>EG-HI-PS500-01</p>
					<p>Цена - 2182,9грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/46.jpg" alt="">
					<p>EG-HI-PS800-01</p>
					<p>Цена - 2814,1грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/47.jpg" alt="">
					<p>EG-HI-PS1000-01</p>
					<p>Цена - 3419грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/48.jpg" alt="">
					<p>EG-UPS-001</p>
					<p>Цена - 1420,2грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/49.jpg" alt="">
					<p>EG-UPS-002</p>
					<p>Цена - 1788,4грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/50.jpg" alt="">
					<p>EG-UPS-031</p>
					<p>Цена - 1446,5грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/51.jpg" alt="">
					<p>EG-UPS-032</p>
					<p>Цена - 1867,3грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/52.jpg" alt="">
					<p>EG-UPS-033</p>
					<p>Цена - 2787,8грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/53.jpg" alt="">
					<p>EG-UPS-034</p>
					<p>Цена - 3787,2грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/54.jpg" alt="">
					<p>EG-UPS-B650</p>
					<p>Цена - 1078,3грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/55.jpg" alt="">
					<p>EG-UPS-B850</p>
					<p>Цена - 1367,6грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/56.jpg" alt="">
					<p>BX1100CI-RS</p>
					<p>Цена - 5496,7грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/57.jpg" alt="">
					<p>BX700UI</p>
					<p>Цена - 2971,9грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/58.jpg" alt="">
					<p>BE400-RS</p>
					<p>Цена - 2498,5грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/59.jpg" alt="">
					<p>BE550G-RS</p>
					<p>Цена - 3234,9грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/60.jpg" alt="">
					<p>BE700G-RS</p>
					<p>Цена - 3603,1грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/61.jpg" alt="">
					<p>BR1200GI</p>
					<p>Цена - 11230,1грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/62.jpg" alt="">
					<p>BR1200G-RS</p>
					<p>Цена - 10967,1грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/63.jpg" alt="">
					<p>BR1500GI</p>
					<p>Цена - 12808,1грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/64.jpg" alt="">
					<p>BR1500G-RS</p>
					<p>Цена - 12492,5грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/65.jpg" alt="">
					<p>SMT1500I</p>
					<p>Цена - 21276,7грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/66.jpg" alt="">
					<p>SMT2200I</p>
					<p>Цена - 31533,7грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/67.jpg" alt="">
					<p>SMT750I</p>
					<p>Цена - 10783грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/68.jpg" alt="">
					<p>SMC2000I</p>
					<p>Цена - 24459грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/69.jpg" alt="">
					<p>SMC1000I-2U</p>
					<p>Цена - 18383,7грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/70.jpg" alt="">
					<p>SUA1000RMI1U</p>
					<p>Цена - 22618грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/71.jpg" alt="">
					<p>SMT1000RMI2U</p>
					<p>Цена - 21171,5грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/72.jpg" alt="">
					<p>SC620I</p>
					<p>Цена - 7153,6грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/73.jpg" alt="">
					<p>SRT8KXLI</p>
					<p>Цена - 144623,7грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/74.jpg" alt="">
					<p>PS-3GS-10</p>
					<p>Цена - 118,4грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/75.jpg" alt="">
					<p>SPM3-G-15G</p>
					<p>Цена - 98,6грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/76.jpg" alt="">
					<p>SPM5-G-6G</p>
					<p>Цена - 85,5грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/77.jpg" alt="">
					<p>SPM5-G-6B</p>
					<p>Цена - 85,5грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/78.jpg" alt="">
					<p>SPM5-G-10G</p>
					<p>Цена - 105,2грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/79.jpg" alt="">
					<p>SPG5-G-10G</p>
					<p>Цена - 111,8грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/80.jpg" alt="">
					<p>SPM5-G-15B</p>
					<p>Цена - 118,4грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/81.jpg" alt="">
					<p>SPM5-G-15G</p>
					<p>Цена - 118,4грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/82.jpg" alt="">
					<p>SPG5-G-10MG</p>
					<p>Цена - 149грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/83.jpg" alt="">
					<p>SPG6-G-6B</p>
					<p>Цена - 105,2грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/84.jpg" alt="">
					<p>SPG6-G-6G</p>
					<p>Цена - 105,2грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/85.jpg" alt="">
					<p>SPG6-G-10G</p>
					<p>Цена - 118,4грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/86.jpg" alt="">
					<p>SPG6-G-15G</p>
					<p>Цена - 131,5грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/87.jpg" alt="">
					<p>SPG5-U-5</p>
					<p>Цена - 315,6грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_pitanie/88.jpg" alt="">
					<p>SPM5-G-6G</p>
					<p>Цена - 85,5грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
	</div>


	<!-- ModalWindow buy -->
	<div class="ModalWindow buy " id="ModalWindow">
        <a class="close" id="close">X</a>

        <form method="post" action="/form.php" id="formMain" name="formMain" >
            <h2>Выберите товар и сделайте заказ</h2> 
                <select id="name" type="text" size="0" name="hero[]" required>
                    <option selected disabled>Выберите товар</option>
                    <option value="Блок питания Full Energy BGW-122 12В/2А">Блок питания Full Energy BGW-122 12В/2А</option>
                    <option value="PSW-240-12G">PSW-240-12G</option>
                    <option value="PSW-250-12">PSW-250-12</option>
                    <option value="HKA-A24250-230">HKA-A24250-230</option>
                    <option value="Блок питания Foscam 5В 2А DC">Блок питания Foscam 5В 2А DC</option>
                    <option value="Блок питания Foscam 12В 2А DC">Блок питания Foscam 12В 2А DC</option>
                    <option value="Страж 1,5А">Страж 1,5А</option>
                    <option value="Страж М-910/12">Страж М-910/12</option>
                    <option value="Страж М-910">Страж М-910</option>
                    <option value="Блок питания ATABA-1230 12V/3A с кабелем питания">Блок питания ATABA-1230 12V/3A с кабелем питания</option>
                    <option value="Страж М-924">Страж М-924</option>
                    <option value="Страж М-912">Страж М-912</option>
                    <option value="Блок бесперебойного питания Full Energy BBG-124/4">Блок бесперебойного питания Full Energy BBG-124/4</option>
                    <option value="Блок бесперебойного питания Full Energy BBG-1210/8">Блок бесперебойного питания Full Energy BBG-1210/8</option>
                    <option value="Блок бесперебойного питания Kraft PSU-1203LED">Блок бесперебойного питания Kraft PSU-1203LED</option>
                    <option value="Блок бесперебойного питания Kraft PSU-1203/4CH">Блок бесперебойного питания Kraft PSU-1203/4CH</option>
                    <option value="Блок бесперебойного питания Kraft PSU-1205LED">Блок бесперебойного питания Kraft PSU-1205LED</option>
                    <option value="Блок бесперебойного питания Kraft PSU-1205/8CH">Блок бесперебойного питания Kraft PSU-1205/8CH</option>
                    <option value="Блок бесперебойного питания Kraft PSU-1210LED">Блок бесперебойного питания Kraft PSU-1210LED</option>
                    <option value="Блок бесперебойного питания Kraft PSU-1210/16CH">Блок бесперебойного питания Kraft PSU-1210/16CH</option>
                    <option value="Источник бесперебойного питания SVS-DC12A8-8/17">Источник бесперебойного питания SVS-DC12A8-8/17</option>
                    <option value="Блок бесперебойного питания Trinix PSU 6A 12B">Блок бесперебойного питания Trinix PSU 6A 12B</option>
                    <option value="Блок бесперебойного питания Nikton ББП50Л-12Б">Блок бесперебойного питания Nikton ББП50Л-12Б</option>
                    <option value="Блок бесперебойного питания Nikton ББП125И-12Б">Блок бесперебойного питания Nikton ББП125И-12Б</option>
                    <option value="Блок бесперебойного питания Nikton ББП40М-12Б">Блок бесперебойного питания Nikton ББП40М-12Б</option>
                    <option value="Аккумуляторная батарея Full Energy 12V 1.2Ah (FEP-121)">Аккумуляторная батарея Full Energy 12V 1.2Ah (FEP-121)</option>
                    <option value="Аккумуляторная батарея Full Energy 12V 2,2Ah (FEP-122)">Аккумуляторная батарея Full Energy 12V 2,2Ah (FEP-122)</option>
                    <option value="Аккумуляторная батарея Full Energy 12V 4Ah (FEP-124)">Аккумуляторная батарея Full Energy 12V 4Ah (FEP-124)</option>
                    <option value="Аккумуляторная батарея Full Energy 12V 7Ah (FE-7-12)">Аккумуляторная батарея Full Energy 12V 7Ah (FE-7-12)</option>
                    <option value="Аккумуляторная батарея Full Energy 12V 12Ah (FE-1212)">Аккумуляторная батарея Full Energy 12V 12Ah (FE-1212)</option>
                    <option value="Аккумуляторная батарея Full Energy 12V 18Ah (FEP-1218)">Аккумуляторная батарея Full Energy 12V 18Ah (FEP-1218)</option>
                    <option value="Аккумуляторная батарея Trinix АКБ 12V 1,2Ah">Аккумуляторная батарея Trinix АКБ 12V 1,2Ah</option>
                    <option value="Аккумуляторная батарея Trinix АКБ 12V 4Ah">Аккумуляторная батарея Trinix АКБ 12V 4Ah</option>
                    <option value="Аккумуляторная батаре Trinix АКБ 12V 7Ah">Аккумуляторная батаре Trinix АКБ 12V 7Ah</option>
                    <option value="Аккумуляторная батарея Trinix АКБ 12V 18Ah">Аккумуляторная батарея Trinix АКБ 12V 18Ah</option>
                    <option value="BAT-6V4.5AH">BAT-6V4.5AH</option>
                    <option value="BAT-12V4.5AH ">BAT-12V4.5AH </option>
                    <option value="BAT-12V7AH">BAT-12V7AH</option>
                    <option value="BAT-12V9AH">BAT-12V9AH</option>
                    <option value="BAT-12V12AH">BAT-12V12AH</option>
                    <option value="BAT-12V17AH/4">BAT-12V17AH/4</option>
                    <option value="BAT-12V30AH">BAT-12V30AH</option>
                    <option value="BAT-12V40AH">BAT-12V40AH</option>
                    <option value="BAT-12V55AH">BAT-12V55AH</option>
                    <option value="BAT-12V80AH">BAT-12V80AH</option>
                    <option value="EG-HI-PS500-01">EG-HI-PS500-01</option>
                    <option value="EG-HI-PS800-01">EG-HI-PS800-01</option>
                    <option value="EG-HI-PS1000-01">EG-HI-PS1000-01</option>
                    <option value="EG-UPS-001">EG-UPS-001</option>
                    <option value="EG-UPS-002">EG-UPS-002</option>
                    <option value="EG-UPS-031">EG-UPS-031</option>
                    <option value="EG-UPS-032">EG-UPS-032</option>
                    <option value="EG-UPS-033">EG-UPS-033</option>
                    <option value="EG-UPS-034">EG-UPS-034</option>
                    <option value="EG-UPS-B650">EG-UPS-B650</option>
                    <option value="EG-UPS-B850">EG-UPS-B850</option>
                    <option value="BX1100CI-RS">BX1100CI-RS</option>
                    <option value="BX700UI">BX700UI</option>
                    <option value="BE400-RS">BE400-RS</option>
                    <option value="BE550G-RS">BE550G-RS</option>
                    <option value="BE700G-RS">BE700G-RS</option>
                    <option value="BR1200GI">BR1200GI</option>
                    <option value="BR1200G-RS">BR1200G-RS</option>
                    <option value="BR1500GI">BR1500GI</option>
                    <option value="BR1500G-RS">BR1500G-RS</option>
                    <option value="SMT1500I">SMT1500I</option>
                    <option value="SMT2200I">SMT2200I</option>
                    <option value="SMT750I">SMT750I</option>
                    <option value="SMC2000I">SMC2000I</option>
                    <option value="SMC1000I-2U">SMC1000I-2U</option>
                    <option value="SUA1000RMI1U">SUA1000RMI1U</option>
                    <option value="SMT1000RMI2U">SMT1000RMI2U</option>
                    <option value="SC620I">SC620I</option>
                    <option value="SRT8KXLI">SRT8KXLI</option>
                    <option value="PS-3GS-10">PS-3GS-10</option>
                    <option value="SPM3-G-15G">SPM3-G-15G</option>
                    <option value="SPM5-G-6G">SPM5-G-6G</option>
                    <option value="SPM5-G-6B">SPM5-G-6B</option>
                    <option value="SPM5-G-10G">SPM5-G-10G</option>
                    <option value="SPG5-G-10G">SPG5-G-10G</option>
                    <option value="SPM5-G-15B">SPM5-G-15B</option>
                    <option value="SPM5-G-15G">SPM5-G-15G</option>
                    <option value="SPG5-G-10MG">SPG5-G-10MG</option>
                    <option value="SPG6-G-6B">SPG6-G-6B</option>
                    <option value="SPG6-G-6G">SPG6-G-6G</option>
                    <option value="SPG6-G-10G">SPG6-G-10G</option>
                    <option value="SPG6-G-15G">SPG6-G-15G</option>
                    <option value="SPG5-U-5">SPG5-U-5</option>
            <input id="telephone" type="number" name="telephone"  placeholder="Ваш телефон...." maxlength="30" autocomplete="off" required/>
            <input id="mail" type="email" name="mail"  placeholder="Ваш Email...." maxlength="30" autocomplete="off" required/>
            <input id="button" name="send" type="submit" value="Заказать товар"/>
        </form>
    </div>

<?php
	require '../link/footer.php';

?>	
