<?php
	require '../link/header.php';
?>
	<title>Аксесуары</title>
	<a style="margin-left:90px; color:red; font-size: 18px; font-weight: bold; text-transform:uppercase;" href="/index.php">Вернуться на главную</a>
	<div class="container-fluid accessories_acsesuars">
		<h2>Аксесуары</h2>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_acsesuars/1.jpg" alt="">
					<p>Патч-корд 5м UTP, Cat.5e RITAR литой синий</p>
					<p>Цена - 33,4грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_acsesuars/2.jpg" alt="">
					<p>Кабель 18,3 м BNC-M + BNC-M</p>
					<p>Цена - 230,1грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_acsesuars/3.jpg" alt="">
					<p>Кабель 18,3 м BNC-RCA-M + BNC-RCA-M</p>
					<p>Цена - 499,7грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_acsesuars/4.jpg" alt="">
					<p>Гермобокс Z-90</p>
					<p>Цена - 273,5грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_acsesuars/5.jpg" alt="">
					<p>Коробка распределительная OBO T-40 90x90x52 IP55</p>
					<p>Цена - 47,3грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_acsesuars/6.jpg" alt="">
					<p>Коробка распределительная OBO T-100 151x117x67 IP66</p>
					<p>Цена - 134,1грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_acsesuars/7.jpg" alt="">
					<p>Распределительная коробка 120*120*100 IP65 Get-san</p>
					<p>Цена - 126,2грн</p
	
						<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_acsesuars/8.jpg" alt="">
					<p>Распределительная коробка 160*160*75 IP65 Get-san</p>
					<p>Цена - 157,8грн</p
	
						<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>				</div>	
			</div>
		</div>
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_acsesuars/9.jpg" alt="">
					<p>Распределительная коробка 85*85*40 IP54 Get-san</p>
					<p>Цена - 26,3грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_acsesuars/10.jpg" alt="">
					<p>Распределительная коробка 125*100*75 IP65 Get-san</p>
					<p>Цена - 118,4грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_acsesuars/11.jpg" alt="">
					<p>Коробка монтажная пластиковая для СКУД  350х255х120 </p>
					<p>Цена - 276,2грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_acsesuars/12.jpg" alt="">
					<p>Антивандальный бокс B-150</p>
					<p>Цена - 526грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>	
		<div class="row justify-content-lg-center">
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_acsesuars/13.jpg" alt="">
					<p>Антивандальный бокс B-250</p>
					<p>Цена - 1052грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_acsesuars/14.jpg" alt="">
					<p>Распределительная коробка 125*100*75 IP65 Get-san</p>
					<p>Цена - 118,4грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_acsesuars/15.jpg" alt="">
					<p>1х8 CAB-8POWER (Разветвитель питания 1 к 8)</p>
					<p>Цена - 155,2грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
			<div class="col-lg-3">
				<div class="block_accessories">
					<img src="/images/accessories_acsesuars/16.jpg" alt="">
					<p>1х4 CAB-4POWER (Разветвитель питания 1 к 4)</p>
					<p>Цена - 123,3грн</p>
					<center><button class="main_button_all_catalog vizov_buy" >Заказать</button></center>
				</div>	
			</div>
		</div>
	</div>


	<!-- ModalWindow buy -->
	<div class="ModalWindow buy " id="ModalWindow">
        <a class="close" id="close">X</a>

        <form method="post" action="/form.php" id="formMain" name="formMain" >
            <h2>Выберите товар и сделайте заказ</h2> 
                <select id="name" type="text" size="0" name="hero[]" required>
                    <option selected disabled>Выберите товар</option>
                    <option value="Модель: Tecsar 1OUT">Патч-корд 5м UTP, Cat.5e RITAR литой синий</option>
                    <option value="Модель: Tecsar 2OUT">Кабель 18,3 м BNC-M + BNC-M</option>
                    <option value="Модель: Tecsar 2OUT LUX LITE">Кабель 18,3 м BNC-RCA-M + BNC-RCA-M</option>
                    <option value="Модель: Tecsar 2OUT Var">Гермобокс Z-90</option>
                    <option value="Модель: Tecsar 4OUT">Коробка распределительная OBO T-40 90x90x52 IP55</option>
                    <option value="Модель: Tecsar 4OUT LUX">Коробка распределительная OBO T-100 151x117x67 IP66</option>
                    <option value="Модель: Tecsar 6dom LUX LITE">Распределительная коробка 120*120*100 IP65 Get-san</option>
                    <option value="Модель: Tecsar 8OUT-MIX">Распределительная коробка 160*160*75 IP65 Get-san</option>
                    <option value="Модель: Dahua 4MIX HD">Распределительная коробка 85*85*40 IP54 Get-san</option>
                    <option value="Модель: Dahua 4MIX HD">Распределительная коробка 125*100*75 IP65 Get-san</option>
                    <option value="Модель: Dahua DH-IPC-A15P">Коробка монтажная пластиковая для СКУД  350х255х120 </option>
                    <option value="Модель: Dahua DH-IPC-C15P">Антивандальный бокс B-150</option>
                    <option value="Модель: Dahua DH-IPC-C15P">Антивандальный бокс B-250</option>
                    <option value="Модель: Dahua DH-IPC-C15P">1х8 CAB-8POWER (Разветвитель питания 1 к 8)</option>
                    <option value="Модель: Dahua DH-IPC-C15P">1х4 CAB-4POWER (Разветвитель питания 1 к 4)</option>
            <input id="telephone" type="number" name="telephone"  placeholder="Ваш телефон...." maxlength="30" autocomplete="off" required/>
            <input id="mail" type="email" name="mail"  placeholder="Ваш Email...." maxlength="30" autocomplete="off" required/>
            <input id="button" name="send" type="submit" value="Заказать товар"/>
        </form>
    </div>

<?php
	require '../link/footer.php';

?>	
